
<div align="center">
<img width="100" src="img/ibm.png">
<img width="100" src="img/etec.jpg"> 
</div>
<br></br>
<div align="center"> 
  
# Portfólio do curso de Desenvolvimento de Sistemas-AMS ETEC Zona Leste

Olá!, me chamo João Pedro Silva de Oliveira, bem-vindo ao meu repositório que documenta minha trajetória no curso de Desenvolvimento de Sistemas (AMS) na ETEC Zona Leste.

<br></br>
## Sobre o Curso

O curso AMS na ETEC Zona Leste é uma oportunidade única para adquirir habilidades práticas e teóricas essenciais no desenvolvimento de sistemas. Durante este percurso, explorei uma variedade de tecnologias e conceitos fundamentais, preparando-me para desafios do mundo real.

<br></br>

## Contato
<div align="center"> 
Caso queira enviar algum feedback, sinta-se a vontade em entrar em contato comigo através do contato abaixo.

  
<a href="https://www.linkedin.com/in/ricardo-luquetti-codo-835a5125b" target="_blank"><img src="img/lik.png" target="_blank"></a> 
 </div>
</div>